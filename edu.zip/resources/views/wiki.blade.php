@extends('MediaWiki.index')

@section('content')
{!!$page!!}
@endsection
<!DOCTYPE html>
