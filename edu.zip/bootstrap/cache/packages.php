<?php return array (
  'devdojo/chatter' => 
  array (
    'providers' => 
    array (
      0 => 'DevDojo\\Chatter\\ChatterServiceProvider',
    ),
  ),
  'illuminated/wikipedia-grabber' => 
  array (
    'providers' => 
    array (
      0 => 'Illuminated\\Wikipedia\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Wikipedia' => 'Illuminated\\Wikipedia\\Wikipedia',
      'MediaWiki' => 'Illuminated\\Wikipedia\\MediaWiki',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'unisharp/laravel-filemanager' => 
  array (
    'providers' => 
    array (
      0 => 'UniSharp\\LaravelFilemanager\\LaravelFilemanagerServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
);