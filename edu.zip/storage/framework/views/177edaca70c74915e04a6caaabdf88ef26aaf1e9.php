<?php $__env->startSection('content'); ?>
<?php echo $page; ?>

<?php $__env->stopSection(); ?>
<!DOCTYPE html>

<?php echo $__env->make('MediaWiki.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>