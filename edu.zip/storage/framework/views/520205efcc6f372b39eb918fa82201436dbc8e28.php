<?php $__env->startSection('content'); ?>
<div class="row">


      <div class="sub-title">
        <h2>Modern Edusystem</h2>
          <a href="/"><i class="icon-envelope"></i></a>
       </div>


      <div class="col-md-12 content-page">
        <?php if($blogs->count()==0): ?>
          <div class="post-info">
            <h1>No Blogs</h1>
          </div>
        <?php endif; ?>

          <!-- Blog Post Start -->
          <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-12 blog-post">
              <div class="post-title">
                <a href="/viewblog/<?php echo e($blog->id); ?>"><h1><?php echo e($blog->title); ?></h1></a>
              </div>
              <div class="post-info">
                <span><?php echo e($blog->created_at->diffForHumans()); ?>/ by <a href="#" target="_blank"><?php echo e($blog->author); ?></a></span>
              </div>
              <p><?php echo str_limit($blog->content, $limit = 350, $end = "..."); ?></p>
              <a href="/viewblog/<?php echo e($blog->id); ?>" class="button button-style button-anim fa fa-long-arrow-right"><span>Read More</span></a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- Blog Post End -->

          <div class="col-md-12 text-center">
           <a href="javascript:void(0)" id="load-more-post" class="load-more-button">Load</a>
           <div id="post-end-message"></div>
          </div>

       </div>

   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.imondmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>